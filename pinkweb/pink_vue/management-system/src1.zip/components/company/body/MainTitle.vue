<template>
  <div class="page-title">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: "MainTitle"
}
</script>

<style scoped>
@import "../../../assets/css/company/components/maintitle.css";
</style>
